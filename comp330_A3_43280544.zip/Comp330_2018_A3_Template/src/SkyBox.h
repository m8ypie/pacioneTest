/*
 * SkyBox.h
 *
 *  Created on: 20May,2018
 *      Author: guy_w
 */

#ifndef SKYBOX_H_
#define SKYBOX_H_
#include <vector>
#include "utilities.h"


class SkyBox {

private:
		std::vector<Vector3> stars;

public:
	SkyBox();
	void drawBox();
};

#endif /* SKYBOX_H_ */
