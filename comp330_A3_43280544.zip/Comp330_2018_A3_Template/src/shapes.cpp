#include "shapes.h"
#include "utilities.h"
#include <vector>
#include <GL/glut.h>
#include <GL/glu.h>
#include <math.h>
void drawSphere () {
	const float radius = 1.0f;
	const int slices = 64;
	const int stacks = 32;

	static bool compiled = false;
	static unsigned int sphereList = glGenLists(1);

	static GLUquadric* sphereQuadric = gluNewQuadric();

	if (!compiled) {
		gluQuadricTexture(sphereQuadric, true);
		glNewList(sphereList, GL_COMPILE);
			glPushMatrix();
				glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
				gluSphere(sphereQuadric, radius, slices, stacks);
			glPopMatrix();
		glEndList();
		compiled = true;
	}

	glCallList(sphereList);
}

void drawCircle () {
	const float sides = 128.0f;
	const float step = (2.0 * M_PI) / sides;

	static bool compiled = false;
	static unsigned int circleList = glGenLists(1);

	if (!compiled) {
		glNewList(circleList, GL_COMPILE);
			glBegin(GL_LINE_LOOP);
				for (float theta = 0; theta < 2 * M_PI; theta += step) {
					float x = cos(theta);
					float y = sin(theta);
					glVertex2f(x, y);
				}
			glEnd();
		glEndList();
		compiled = true;
	}

	glCallList(circleList);
}

void drawSquare() {
	 glBegin(GL_POLYGON);
	  glTexCoord2f(0.0,0.0); glVertex3f(0.0, 0.0, 0.0);
	  glTexCoord2f(0.0,1.0); glVertex3f(0.0, 1.0, 0.0);
	  glTexCoord2f(1.0,1.0); glVertex3f(1.0, 1.0, 0.0);
	  glTexCoord2f(1.0,0.0); glVertex3f(1.0, 0.0, 0.0);
	 glEnd();
}

void drawCube () {
	static bool compiled = false;
	static unsigned int cubeList = glGenLists(1);

	if (!compiled) {
		glNewList(cubeList, GL_COMPILE);
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 1.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f( 0.5f,  0.5f, -0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f( -0.5f, 0.5f, -0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f( -0.5f, 0.5f,  0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f( 0.5f,  0.5f,  0.5f);

				glNormal3f(0.0f, -1.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f(-0.5f, -0.5f, -0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f( 0.5f, -0.5f, -0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f( 0.5f, -0.5f,  0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f(-0.5f, -0.5f,  0.5f);

				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f( 0.5f,  0.5f,  0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-0.5f,  0.5f,  0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-0.5f, -0.5f,  0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f( 0.5f, -0.5f,  0.5f);

				glNormal3f(0.0f, 0.0f, -1.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f( 0.5f, -0.5f, -0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-0.5f, -0.5f, -0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-0.5f,  0.5f, -0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f( 0.5f,  0.5f, -0.5f);

				glNormal3f(-1.0f, 0.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f(-0.5f,  0.5f,  0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-0.5f,  0.5f, -0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-0.5f, -0.5f, -0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f(-0.5f, -0.5f,  0.5f);

				glNormal3f(1.0f, 0.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f( 0.5f,  0.5f, -0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f( 0.5f,  0.5f,  0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f( 0.5f, -0.5f,  0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f( 0.5f, -0.5f, -0.5f);
			glEnd();
		glEndList();
		compiled = true;
	}

	glCallList(cubeList);
}


void drawIndpCube (struct Faces faces) {
	static bool compiled = false;
	static unsigned int indpCubeList = glGenLists(1);
	unsigned int texture = -1;
	if (!compiled) {
		glNewList(indpCubeList, GL_COMPILE);
			texture = loadGLTexture(faces.front.c_str());
			glBindTexture(GL_TEXTURE_2D, texture);
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 1.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f( 0.5f,  0.5f, -0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f( -0.5f, 0.5f, -0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f( -0.5f, 0.5f,  0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f( 0.5f,  0.5f,  0.5f);
			glEnd();
			glBegin(GL_QUADS);
			texture = loadGLTexture(faces.back.c_str());
			glBindTexture(GL_TEXTURE_2D, texture);
				glNormal3f(0.0f, -1.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f(-0.5f, -0.5f, -0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f( 0.5f, -0.5f, -0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f( 0.5f, -0.5f,  0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f(-0.5f, -0.5f,  0.5f);
			glEnd();
			glBegin(GL_QUADS);
			texture = loadGLTexture(faces.top.c_str());
			glBindTexture(GL_TEXTURE_2D, texture);
				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f( 0.5f,  0.5f,  0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-0.5f,  0.5f,  0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-0.5f, -0.5f,  0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f( 0.5f, -0.5f,  0.5f);
			glEnd();
			texture = loadGLTexture(faces.bottom.c_str());
			glBindTexture(GL_TEXTURE_2D, texture);
			glBegin(GL_QUADS);
				glNormal3f(0.0f, 0.0f, -1.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f( 0.5f, -0.5f, -0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-0.5f, -0.5f, -0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-0.5f,  0.5f, -0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f( 0.5f,  0.5f, -0.5f);
			glEnd();
			texture = loadGLTexture(faces.left.c_str());
			glBindTexture(GL_TEXTURE_2D, texture);
			glBegin(GL_QUADS);
				glNormal3f(-1.0f, 0.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f(-0.5f,  0.5f,  0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-0.5f,  0.5f, -0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-0.5f, -0.5f, -0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f(-0.5f, -0.5f,  0.5f);
			glEnd();
			texture = loadGLTexture(faces.right.c_str());
			glBindTexture(GL_TEXTURE_2D, texture);
			glBegin(GL_QUADS);
				glNormal3f(1.0f, 0.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f( 0.5f,  0.5f, -0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f( 0.5f,  0.5f,  0.5f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f( 0.5f, -0.5f,  0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f( 0.5f, -0.5f, -0.5f);
			glEnd();
		glEndList();
		compiled = true;
	}

	glCallList(indpCubeList);
}


/*
r = torus ring radius
c = torus tube radius
rSeg, cSeg = number of segments/detail
*/

void drawTorus()
{
	static bool boo = false;
	static unsigned int torusList = glGenLists(1);
	double r = 0.07;
	double c = 0.18;
	int rSeg = 160;
	int cSeg = 80;

	//  glBindTexture(GL_TEXTURE_2D, texture);
	//  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	const double PI = 3.1415926535897932384626433832795;
	const double TAU = 2 * PI;

//	if (!boo) {
		//glNewList(torusList, GL_COMPILE);
		for (int i = 0; i < rSeg; i++) {
			glBegin(GL_QUAD_STRIP);
			for (int j = 0; j <= cSeg; j++) {
				for (int k = 0; k <= 1; k++) {
					double s = (i + k) % rSeg + 0.5;
					double t = j % (cSeg + 1);

					double x = (c + r * cos(s * TAU / rSeg)) * cos(t * TAU / cSeg);
					double y = (c + r * cos(s * TAU / rSeg)) * sin(t * TAU / cSeg);
					double z = r * sin(s * TAU / rSeg);

					double u = (i + k) / (float) rSeg;
					double v = t / (float) cSeg;

					glTexCoord2d(u, v);
					glVertex3f(2 * x, 2 * y, 2 * z);
				}
			}
		glEnd();
		}
//		boo = true;
//	}


	//glCallList(torusList);
}
