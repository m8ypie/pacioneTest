#include "utilities.h"
#include "ViewportPos.h"
#include <string>
const float HORIZONTAL_DIVISION = 0.3f;
Rect bottomRightViewport;
Rect bottomMiddleViewport;
Rect bottomLeftViewport;
Rect topViewport;

//const std::string TOP = "top";
//const std::string LEFT = "left";
//const std::string MIDDLE = "middle";
//const std::string RIGHT = "right";
//
//const std::string REALISTIC = "realistic";
//const std::string SCAN = "scan";
//const std::string SPACECRAFT = "spacecraft";
//const std::string ORBIT = "orbit";

/**
 * Update viewport's sizes when window size changes
 */
void ViewportPos::update(int windowHeight, int windowWidth){
	dividerHeight = windowHeight * HORIZONTAL_DIVISION;
	firstThird = (float) windowWidth * (1.0f / 3.0f);
	secondThird = (float) windowWidth * (2.0f / 3.0f);
	bottomRightViewport.bottomLeftX = secondThird;
	bottomRightViewport.bottomLeftY = 0;
	bottomRightViewport.topRightX = windowWidth;
	bottomRightViewport.topRightY = dividerHeight;


	bottomMiddleViewport.bottomLeftX = firstThird;
	bottomMiddleViewport.bottomLeftY = 0;
	bottomMiddleViewport.topRightX = secondThird;
	bottomMiddleViewport.topRightY = dividerHeight;



	bottomLeftViewport.bottomLeftX = 0;
	bottomLeftViewport.bottomLeftY = 0;
	bottomLeftViewport.topRightX = firstThird;
	bottomLeftViewport.topRightY = dividerHeight;


	topViewport.bottomLeftX = 0;
	topViewport.bottomLeftY = dividerHeight;
	topViewport.topRightX = windowWidth;
	topViewport.topRightY = windowHeight;
}

/**
 * Bring viewport to front main view.
 */
void ViewportPos::toFrontView(std::string viewport){
	Rect* temp = this->viewport[currentTop];
	this->viewport[currentTop] = this->viewport[viewport];
	this->viewport[viewport] = temp;
	currentTop = viewport;
}

/**
 * Get selected viewport position
 */
Rect* ViewportPos::getViewpos(std::string viewport){
	return this->viewport[viewport];
}

/**
 * Determine if the supplied viewport is the current main.
 */
bool ViewportPos::isCurrentTop(std::string viewport){
	return viewport.compare(currentTop) == 0;
}

/**
 * Update port size
 */
void ViewportPos::updatePortSize(int windowHeight, int windowWidth){
	update(windowHeight,windowWidth);
}

ViewportPos::ViewportPos(int windowHeight, int windowWidth){

	TOP = "top";
	LEFT = "left";
	MIDDLE = "middle";
	RIGHT = "right";

	REALISTIC = "realistic";
	SCAN = "scan";
	SPACECRAFT = "spacecraft";
	ORBIT = "orbit";

	currentTop = REALISTIC;

	this->viewport[REALISTIC] = &topViewport;
	this->viewport[SCAN] = &bottomLeftViewport;
	this->viewport[SPACECRAFT] = &bottomMiddleViewport;
	this->viewport[ORBIT] = &bottomRightViewport;
	update(windowHeight,windowWidth);
}

