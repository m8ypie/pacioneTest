#include <map>
#include "utilities.h"
#include <string>

class ViewportPos {

private:
	std::map <std::string, Rect*> viewport;
	std::string currentTop;
	void update(int windowHeight, int windowWidth);
public:
	ViewportPos(int windowHeight, int windowWidth);
	void updatePortSize(int windowHeight, int windowWidth);
	bool isCurrentTop(std::string viewport);
	void toFrontView(std::string viewport);
	Rect* getViewpos(std::string viewport);
	std::string REALISTIC;
	std::string SCAN;
	std::string SPACECRAFT;
	std::string ORBIT;
	std::string TOP;
	std::string LEFT;
	std::string MIDDLE;
	std::string RIGHT;
	int dividerHeight;
	float firstThird;
	float secondThird;
};
