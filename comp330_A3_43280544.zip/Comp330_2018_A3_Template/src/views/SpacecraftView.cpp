/*
 * SpacecraftView.cpp
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#include "SpacecraftView.h"

#include <GL/glut.h>
#include <GL/glu.h>
#include "../utilities.h"

/**
 * Setup spacecraft view
 */
void SpacecraftView::setupView(Rect* screen, Vector3 spacecraftPos, Vector3 moonPos){
	const int viewportWidth = screen->topRightX - screen->bottomLeftX;
	const int viewportHeight = screen->topRightY - screen->bottomLeftY;
	glViewport(screen->bottomLeftX, screen->bottomLeftY, viewportWidth, viewportHeight);

	glScissor(screen->bottomLeftX, screen->bottomLeftY, viewportWidth, viewportHeight);

	glClearColor(0.0f, 0.1f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0f, (float) viewportWidth / (float) viewportHeight, 0.01f, 100.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(spacecraftPos.x, spacecraftPos.y, spacecraftPos.z, moonPos.x, moonPos.y, moonPos.z, 0.0f, 1.0f, 0.0f);
}
