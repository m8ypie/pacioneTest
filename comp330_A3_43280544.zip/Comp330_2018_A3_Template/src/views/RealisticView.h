/*
 * OrbitView.h
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#ifndef VIEWS_REALISTICVIEW_H_
#define VIEWS_REALISTICVIEW_H_
#include "../utilities.h"
class RealisticView {
public:
	void setupView(Rect* screen, Vector3 moonPos);
	void updateView(const float deltaTime);
};

#endif /* VIEWS_REALISTICVIEW_H_ */
