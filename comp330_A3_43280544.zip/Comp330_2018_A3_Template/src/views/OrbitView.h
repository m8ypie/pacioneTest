/*
 * OrbitView.h
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#ifndef VIEWS_ORBITVIEW_H_
#define VIEWS_ORBITVIEW_H_
#include "../utilities.h"
class OrbitView {
public:
	void setupView(Rect* screen, Vector3 moonPos);
};

#endif /* VIEWS_ORBITVIEW_H_ */
