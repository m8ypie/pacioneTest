/*
 * SpacecraftView.h
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#ifndef VIEWS_SPACECRAFTVIEW_H_
#define VIEWS_SPACECRAFTVIEW_H_
#include "../utilities.h"
class SpacecraftView {
public:
	void setupView(Rect* screen, Vector3 spacecraftPos, Vector3 moonPos);
	void updateView(const float deltaTime);
};

#endif /* VIEWS_SPACECRAFTVIEW_H_ */
