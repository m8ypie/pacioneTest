/*
 * OrbitView.cpp
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#include "RealisticView.h"

#include <GL/glut.h>
#include <GL/glu.h>
#include "../utilities.h"

/**
 * Setup realistic view
 */
void RealisticView::setupView(Rect* screen, Vector3 moonPos){
	const int viewportWidth = screen->topRightX - screen->bottomLeftX;
	const int viewportHeight = screen->topRightY - screen->bottomLeftY;
	glViewport(screen->bottomLeftX, screen->bottomLeftY, viewportWidth, viewportHeight);

	glScissor(screen->bottomLeftX, screen->bottomLeftY, viewportWidth, viewportHeight);

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0f, (float) viewportWidth / (float) viewportHeight, 0.01f, 100.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(moonPos.x + 2.0f, moonPos.y + 1.0f, moonPos.z + 2.0f, moonPos.x, moonPos.y, moonPos.z, 0.0f, 1.0f, 0.0f);
}


