/*
 * ScanView.cpp
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#include "ScanView.h"


#include <GL/glut.h>
#include <GL/glu.h>
#include "../utilities.h"
#include <string>
#include <stdio.h>

/**
 * Setup scan view
 */
void ScanView::setupView(Rect* screen){
	const int viewportWidth = screen->topRightX - screen->bottomLeftX;
	const int viewportHeight = screen->topRightY - screen->bottomLeftY;
	glViewport(screen->bottomLeftX, screen->bottomLeftY, viewportWidth, viewportHeight);

	glScissor(screen->bottomLeftX, screen->bottomLeftY, viewportWidth, viewportHeight);

	glClearColor(0.1f, 0.0f, 0.1f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
