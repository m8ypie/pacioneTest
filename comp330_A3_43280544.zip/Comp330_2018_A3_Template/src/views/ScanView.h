/*
 * ScanView.h
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#ifndef VIEWS_SCANVIEW_H_
#define VIEWS_SCANVIEW_H_
#include <string>
#include "../utilities.h"
class ScanView {
public:
	void setupView(Rect* screen);
};

#endif /* VIEWS_SCANVIEW_H_ */
