/*
 * OrbitView.cpp
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#include "OrbitView.h"


#include <GL/glut.h>
#include <GL/glu.h>
#include "../utilities.h"
#include <stdio.h>

/**
 * Setup orbit view
 */
void OrbitView::setupView(Rect* screen, Vector3 moonPos){
	const int viewportWidth = screen->topRightX - screen->bottomLeftX;
	const int viewportHeight = screen->topRightY - screen->bottomLeftY;
	glViewport(screen->bottomLeftX, screen->bottomLeftY, viewportWidth, viewportHeight);

	glScissor(screen->bottomLeftX, screen->bottomLeftY, viewportWidth, viewportHeight);

	glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	const float worldWindowHalfWidth = 7.0f;
	const float aspectRatio = (float) viewportHeight / (float) viewportWidth;
	glOrtho(-worldWindowHalfWidth, worldWindowHalfWidth, -worldWindowHalfWidth * aspectRatio, worldWindowHalfWidth * aspectRatio, -1.0f, 1.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
