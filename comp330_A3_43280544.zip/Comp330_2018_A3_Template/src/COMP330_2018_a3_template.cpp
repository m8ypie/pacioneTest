/*
COMP330 - 2018

Assignment 3 Template

Author: Peter Reeves

Date: 27 April 2018

Purpose: To help you get started with Assignment 3. Please see the Assignment 3 description (spec) document for a full
description of the requirements. We strongly recommend that you use this code template as a starting point for your work.
But it is not meant to constrain your efforts in any way, and you do not have to use it if you prefer not to do so.

Textures:
	- Stars:         http://forums.newtek.com/showthread.php?90366-Real-3D-Stars
	- Saturn Planet: https://www.solarsystemscope.com/textures/
	- Saturn Rings:  https://alpha-element.deviantart.com/art/Stock-Image-Saturn-Rings-393767006
	- Iapetus:       https://www.jpl.nasa.gov/spaceimages/details.php?id=PIA18436
	- Titan:         http://planet-texture-maps.wikia.com/wiki/Titan
	- Rhea:          http://libroesoterico.com/biblioteca/Astrologia/-%20SOFTWARE/Celestia%20Portable/App/Celestia/textures/hires/
	- Dione:         https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Dione_PIA08413_moon_only.JPG/1024px-Dione_PIA08413_moon_only.JPG
	- Tethys:        https://www.jpl.nasa.gov/spaceimages/details.php?id=PIA14931
	- Enceladus:     http://www.unmannedspaceflight.com/lofiversion/index.php/t5575.html
	- Mimas:         https://saturn.jpl.nasa.gov/resources/7689/mimas-global-map-june-2017/
*/

#include <iostream>
#include <stdlib.h>
#include <string>
#include <stdio.h>
#include <fstream>
#include <time.h>
#include <vector>
#include <GL/glut.h>
#include <GL/glu.h>
#include <math.h>
#include "Soil.h"
#include "utilities.h"
#include "shapes.h"
#include "ViewportPos.h"
#include "moons/Moons.h"
#include "views/OrbitView.h"
#include "views/RealisticView.h"
#include "views/SpacecraftView.h"
#include "views/ScanView.h"
#include "Spacecraft.h"
#include "SkyBox.h"
//#include "ConstructionValues.h"

const int WINDOW_INITIAL_WIDTH = 1024;
const int WINDOW_INITIAL_HEIGHT = 768;



const float FRAMES_PER_SECOND = 60.0f;
const int FRAME_MILLI_WAIT = (int) (1000.0f / FRAMES_PER_SECOND);

int windowWidth = WINDOW_INITIAL_WIDTH;
int windowHeight = WINDOW_INITIAL_HEIGHT;

struct selection {
	std::string label;
	std::string value;
};

selection moonSelection = {
	"Iapetus",
	"iapetus"
};

// Saturn
unsigned int saturnTexture = -1;
const float SATURN_RADIUS = 1.0f;


//Saturn ring
const float saturnRingRadius = SATURN_RADIUS + 5.5f;
//const float ringRadius = 0.7f;
unsigned int saturnRingTexture = -1;
// Iapetus
unsigned int iapetusTexture = -1;
float iapetusOrbitAngle = 0.0f;
const float IAPETUS_RADIUS = 0.5f;
const float IAPETUS_ORBIT_RADIUS = 3.0f;

Moons* moons;

OrbitView* orbitView;
RealisticView* realisticView;
SpacecraftView* spacecraftView;
ScanView* scanView;
Spacecraft* spacecraft;
SkyBox* skyBox;

ViewportPos* viewport;

std::string arr[] = {"1: Iapetus","2: Titan","3: Rhea","4: Dione","5: Tethys","6: Enceladus","7: Mimas" };
std::vector<std::string> moonOptions  (arr, arr + sizeof(arr) / sizeof(arr[0]) );

std::string arr2[] = {"F1: Main","F2: Map","F3: Spacecraft","F4: Orbit"};
std::vector<std::string> viewOptions  (arr2, arr2 + sizeof(arr2) / sizeof(arr2[0]) );

void initialize () {
	// Saturn
	saturnTexture = loadGLTexture("textures/saturn.jpg");
	saturnRingTexture = loadGLTexture("textures/saturn_rings_shadowed_premultiplied.png");
	viewport = new ViewportPos(windowWidth, windowHeight);
	moons = new Moons();
	spacecraft = new Spacecraft(0.02f, 0.02f, 0.02f, 0.0f, 0.95f, -0.5f, moons->getMoonPos(moonSelection.label));
	//views
	orbitView = new OrbitView();
	realisticView = new RealisticView();
	spacecraftView = new SpacecraftView();
	scanView = new ScanView();
	skyBox = new SkyBox();


	glClearColor (0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_SMOOTH);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 0);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glEnable(GL_SCISSOR_TEST);
	glEnable(GL_NORMALIZE);
}

void update (const float currentTime, const float deltaTime) {
	iapetusOrbitAngle += 0.5f * deltaTime;
	moons->updatePosition(deltaTime);
	moons->incMoonScan(moonSelection.label);
	spacecraft->setTargetPlanet(moons->getMoonPos(moonSelection.label));
	spacecraft->updatePosition(deltaTime);
}

void animateSceneTimer (int lastTime) {
	int time = glutGet(GLUT_ELAPSED_TIME);
	glutTimerFunc(FRAME_MILLI_WAIT, animateSceneTimer, time);
	const float deltaTime = ((float)(time - lastTime)) / 1000.0f;
	update(time, deltaTime);
	glutPostRedisplay();
}

void print(std::string s){
	for (std::string::iterator i = s.begin(); i != s.end(); ++i){
		char c = *i;
		glutBitmapCharacter(GLUT_BITMAP_8_BY_13, c);
	}
}

void drawMenu(){
	        //Assume we are in MODEL_VIEW already
		glDisable(GL_LIGHT1);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_CULL_FACE);
		glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);
		glPushMatrix ();
		glLoadIdentity ();
		glMatrixMode(GL_PROJECTION);
		glPushMatrix ();
		glLoadIdentity();

		gluOrtho2D (0,windowWidth, windowHeight, 0);
		glDepthFunc (GL_ALWAYS);
		glColor3f (1,1,1);
		int yPos = 50;
		glRasterPos2f(40, yPos);
		std::string s = "Controls";
		print(s);
		yPos+=20;
		std::vector <std::string>::iterator it;
		for(it = moonOptions.begin(); it != moonOptions.end(); it++ ){
			yPos+=40;
			glRasterPos2f(40, yPos);
			print(*it);
		}
		yPos+=20;
		for(it = viewOptions.begin(); it != viewOptions.end(); it++ ){
			yPos+=40;
			glRasterPos2f(40, yPos);
			print(*it);
		}
		glDepthFunc (GL_LESS);
		glPopMatrix ();
		glMatrixMode(GL_MODELVIEW);
		glPopMatrix ();
}

void display () {

	// Spacecraft
	{

		spacecraftView->setupView(viewport->getViewpos(viewport->SPACECRAFT), spacecraft->position, moons->getMoonPos(moonSelection.label));
		glColorMask(GL_FALSE, GL_TRUE, GL_FALSE, GL_TRUE);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_CULL_FACE);
		glEnable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);

		// Sunlight
		glEnable(GL_LIGHT0);
		const float sunPosition [4] = { 30.0f, 10.0f, 3.0f, 1.0f };
		glLightfv(GL_LIGHT0, GL_POSITION, sunPosition);
		const float sunAmbient [4] = { 0.0f, 0.0f, 0.0f, 1.0f };
		glLightfv(GL_LIGHT0, GL_AMBIENT, sunAmbient);
		const float sunDiffuse [4] = { 1.0f, 1.0f, 0.9f, 1.0f };
		glLightfv(GL_LIGHT0, GL_DIFFUSE, sunDiffuse);

		// Saturn
		glPushMatrix();
			glScalef(SATURN_RADIUS, SATURN_RADIUS, SATURN_RADIUS);
			glColor3f(1.0f, 1.0f, 1.0f);
			glBindTexture(GL_TEXTURE_2D, saturnTexture);
			setMaterial(1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 100.0f, 0.0f, 0.0f, 0.0f);
			drawSphere();
		glPopMatrix();

		glPushMatrix();
			glRotatef(90,0.1,00,0.0);
			glRotatef(-10,0.0,1.0,0.0);
			glRotatef(-7,0.0,0.0,1.0);
			glTranslatef(-saturnRingRadius/2.1, -saturnRingRadius/1.9, SATURN_RADIUS/10);
			glScalef(saturnRingRadius, saturnRingRadius, 1);
			glBindTexture(GL_TEXTURE_2D, saturnRingTexture);
			setMaterial(1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 100.0f, 0.0f, 0.0f, 0.0f);
			glDisable(GL_CULL_FACE);
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			drawSquare();
			glEnable(GL_CULL_FACE);
			glDisable(GL_BLEND);
		glPopMatrix();


		moons->drawRealistic(moonSelection.label, true);
		glColor3f(1.0f, 1.0f, 1.0f);
		skyBox->drawBox();
		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
	}
	if(viewport->isCurrentTop(viewport->SPACECRAFT)){
		drawMenu();
	}

	// Realistic
	{
		realisticView->setupView(viewport->getViewpos(viewport->REALISTIC), moons->getMoonPos(moonSelection.label));
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);

		glDisable(GL_CULL_FACE);
		skyBox->drawBox();
		//glEnable(GL_CULL_FACE);

		// Sunlight
		glEnable(GL_LIGHT0);
		const float sunPosition [4] = { 30.0f, 10.0f, 3.0f, 1.0f };
		glLightfv(GL_LIGHT0, GL_POSITION, sunPosition);
		const float sunAmbient [4] = { 0.0f, 0.0f, 0.0f, 1.0f };
		glLightfv(GL_LIGHT0, GL_AMBIENT, sunAmbient);
		const float sunDiffuse [4] = { 1.0f, 1.0f, 0.9f, 1.0f };
		glLightfv(GL_LIGHT0, GL_DIFFUSE, sunDiffuse);
		glColor3f(1.0f, 1.0f, 1.0f);

		moons->drawRealistic("doesntMatter", false);
		spacecraft->drawRealistic();
		// Saturn
		glPushMatrix();
			glScalef(SATURN_RADIUS, SATURN_RADIUS, SATURN_RADIUS);
			glBindTexture(GL_TEXTURE_2D, saturnTexture);
			setMaterial(1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 100.0f, 0.0f, 0.0f, 0.0f);
			drawSphere();
		glPopMatrix();
		glPushMatrix();
			glRotatef(90,0.1,00,0.0);
			glRotatef(-10,0.0,1.0,0.0);
			glRotatef(-7,0.0,0.0,1.0);
			glTranslatef(-saturnRingRadius/2.1, -saturnRingRadius/1.9, SATURN_RADIUS/10);
			glScalef(saturnRingRadius, saturnRingRadius, 1);
			glBindTexture(GL_TEXTURE_2D, saturnRingTexture);
			setMaterial(1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 100.0f, 0.0f, 0.0f, 0.0f);
			glDisable(GL_CULL_FACE);
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			drawSquare();
			glEnable(GL_CULL_FACE);
			glDisable(GL_BLEND);
		glPopMatrix();

	}
	if(viewport->isCurrentTop(viewport->REALISTIC)){
		drawMenu();
	}

	// Orbit
	{
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_CULL_FACE);
		glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);

		orbitView->setupView(viewport->getViewpos(viewport->ORBIT), moons->getMoonPos(moonSelection.label));
		glPushMatrix();
			glScalef(0.3f, 0.3f, 1.0f);

			glColor3f(1.0f, 1.0f, 1.0f);

			moons->drawOrbitPath(moonSelection.label);

			// Saturn Planet
			glPushMatrix();
				glScalef(SATURN_RADIUS, SATURN_RADIUS, SATURN_RADIUS);
				drawCircle();
				drawString("Saturn");
			glPopMatrix();

			moons->drawOrbit();
			spacecraft->drawOrbit();
		glPopMatrix();
	}
	if(viewport->isCurrentTop(viewport->ORBIT)){
		drawMenu();
	}


	{
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_CULL_FACE);
		glDisable(GL_LIGHTING);
		glEnable(GL_TEXTURE_2D);
		scanView->setupView(viewport->getViewpos(viewport->SCAN));
		glPushMatrix();
			glColor3f(1.0f, 1.0f, 1.0f);
			moons->drawScan(moonSelection.label);
		glPopMatrix();
	};
	if(viewport->isCurrentTop(viewport->SCAN)){
		drawMenu();
	}
	glutSwapBuffers();
}

void keyboard (unsigned char key, int x, int y) {
	switch (key) {
		case '1': {
			moonSelection = {
				"Iapetus",
				"iapetus"
			};
		} break;
		case '2': {
			moonSelection = {
				"Titan",
				"titan"
			};
		} break;
		case '3': {
			moonSelection = {
				"Rhea",
				"rhea"
			};
		} break;
		case '4': {
			moonSelection = {
				"Dione",
				"dione"
			};
		} break;
		case '5': {
			moonSelection = {
				"Tethys",
				"tethys"
			};
		} break;
		case '6': {
			moonSelection = {
				"Enceladus",
				"enceladus"
			};
		} break;
		case '7': {
			moonSelection = {
				"Mimas",
				"mimas"
			};
		} break;

		case 27: {
			exit(0);
		} break;
	}
}

void special_input (int key, int x, int y) {
	switch (key)	{
		case GLUT_KEY_UP: {

		} break;

		case GLUT_KEY_F1: {
			viewport->toFrontView(viewport->REALISTIC);
		} break;

		case GLUT_KEY_F2: {
			viewport->toFrontView(viewport->SCAN);
		} break;

		case GLUT_KEY_F3: {
			viewport->toFrontView(viewport->SPACECRAFT);
		} break;

		case GLUT_KEY_F4: {
			viewport->toFrontView(viewport->ORBIT);
		} break;
	}
}

void resize (int width, int height) {
	windowWidth = width;
	windowHeight = height;
	viewport->updatePortSize(windowHeight, windowWidth);
}

int main (int argc, char** argv) {
	// GLUT setup
	glutInit(&argc, argv);
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(windowWidth, windowHeight);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Mission Control");
	glutDisplayFunc(display);
	glutSpecialFunc(special_input);
	glutKeyboardFunc(keyboard);
	glutReshapeFunc(resize);
	initialize();
	animateSceneTimer(FRAME_MILLI_WAIT);
	glutMainLoop();
	return 0;
}
