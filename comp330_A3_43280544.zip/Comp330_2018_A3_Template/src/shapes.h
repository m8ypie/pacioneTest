/* File: shapes.h
 * Author: Peter Reeves
 * Date: 27 April 2018
 *
 * A variety of shapes can be drawn using the functions in this file.
 *     - drawSphere()
 *         Sphere with radius 1.0
 *     - drawCircle()
 *         Circle with radius 1.0
 *     - drawCube()
 *         Cube with side lengths of 1.0
 *
 */
#ifndef SHAPES_H_
#define SHAPES_H_
#include <string>

void drawSphere ();

void drawCircle ();

void drawSquare();

void drawTorus();


struct Faces {
	std::string top;
	std::string bottom;
	std::string left;
	std::string right;
	std::string front;
	std::string back;
};


void drawIndpCube(Faces faces);

void drawCube ();
#endif /* SHAPES_H_ */
