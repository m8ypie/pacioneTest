/*
 * spacecraft.cpp
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#include "Spacecraft.h"
#include "utilities.h"
#include <GL/glut.h>
#include <GL/glu.h>
#include <math.h>
#include <vector>
#include <stdio.h>
#include <deque>
#include "shapes.h"

const int VECTOR_LIMIT = 400;

Spacecraft::Spacecraft(
		float width,
		float height,
		float length,
		float orbitAngle,
		float orbitRadius,
		float orbitSpeed,
		Vector3 targetPlanet
) {
	this->orbitAngle = orbitAngle;
	this->orbitRadius = orbitRadius;
	this->orbitSpeed = orbitSpeed;
	this->targetPlanet = targetPlanet;
	this->width = width;
	this->height = height;
	this->length = length;
}

/**
 * Update spacecraft's position.
 */
void Spacecraft::updatePosition(float deltaTime){
	this->orbitAngle += this->orbitSpeed * deltaTime;
	this->position = {
			targetPlanet.x + this->orbitRadius * cosf(this->orbitAngle),
			targetPlanet.y,
			targetPlanet.z +this->orbitRadius * sinf(this->orbitAngle)
	};
	if(this->orbitTrail.size() >= VECTOR_LIMIT){
		this->orbitTrail.pop_front();
	}
	this->orbitTrail.push_back({this->position.x, this->position.y, this->position.z});
}

/**
 * Draw spacecraft in realistic view
 */
void Spacecraft::drawRealistic(){
	glPushMatrix();
		glTranslatef(this->position.x, this->position.y, this->position.z);
		glScalef(this->width, this->height, this->length);
		drawCube();
	glPopMatrix();
}

/**
 * Draw spacecraft in orbit
 */
void Spacecraft::drawOrbit(){
	glPushMatrix();
		glColor3f(1.0, 0.0, 0.0);
		glTranslatef(this->position.x, this->position.z, 0.0f);
		glScalef(this->width*10, this->height*10, this->length*2);
		drawSquare();
		glFlush();
	glPopMatrix();

	glPushMatrix();
		glColor3f(1.0, 0.0, 0.0);
		std::deque <Vector3>::iterator it;
		glBegin(GL_LINE_STRIP);
			for(it = this->orbitTrail.begin(); it != this->orbitTrail.end(); it++ ){
				glVertex2f(it->x, it->z);
			}
		glEnd();
	glPopMatrix();
}

/**
 * Set spacecraft target planet
 */
void Spacecraft::setTargetPlanet(Vector3 targetPlanet){
	this->targetPlanet = targetPlanet;
}
