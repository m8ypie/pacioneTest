/*
 * spacecraft.h
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#ifndef SPACECRAFT_H_
#define SPACECRAFT_H_
#include "utilities.h"
#include <vector>
#include <deque>
class Spacecraft {
public:
	Vector3 position;

	Spacecraft(
		float width,
		float height,
		float length,
		float orbitAngle,
		float orbitRadius,
		float orbitSpeed,
		Vector3 targetPlanet
	);
	void drawRealistic();
	void setTargetPlanet(Vector3 targetPlanet);
	void drawOrbit();
	void updatePosition(float deltaTime);
private:
	float orbitAngle;
	float orbitRadius;
	float orbitSpeed;
	float width;
	float height;
	float length;
	Vector3 targetPlanet;
	std::deque<Vector3> orbitTrail;
};

#endif /* SPACECRAFT_H_ */
