/*
 * Moons.h
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#ifndef MOONS_H_
#define MOONS_H_
#include <string>
#include <vector>
#include <map>
#include "moon.h"
#include "../utilities.h"
//# define NUM_MOONS = 3
struct MoonConfiguration {
	std::string moonName;
	std::string texture;
	float orbitAngle;
	float orbitRadius;
	float moonRadius;
};

class Moons {
private:
	float scanInc;
public:
	std::map <std::string, Moon*> moons;
	Moons();
	void drawScan(std::string moon);
	void drawRealistic(std::string moonName, bool includeWireFrame);
	void drawOrbit();
	void drawOrbitPath(std::string moon);
	Vector3 getMoonPos(std::string moonName);
	float incMoonScan(std::string);
	void updatePosition(float deltaTime);
	virtual ~Moons();
};

#endif /* MOONS_H_ */
