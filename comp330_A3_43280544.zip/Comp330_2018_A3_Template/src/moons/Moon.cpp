/*
 * Plant.cpp
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#include "Moon.h"
#include <GL/glut.h>
#include <GL/glu.h>
#include <stdio.h>
#include <math.h>
#include "../utilities.h"
#include "../shapes.h"
const float rotationInc = 0.2;
Moon::Moon(
	std::string moonName,
	std::string texture,
	float orbitAngle,
	float orbitRadius,
	float moonRadius
) {
	this->moonRadius = moonRadius;
	this->orbitRadius = orbitRadius;
	this->orbitAngle = orbitAngle;
	this->rotation = 0.0;
	this->texture = loadGLTexture(texture.c_str());
	this->position = {
			this->orbitRadius * cosf(this->orbitAngle),
			0.0f,
			this->orbitRadius * sinf(this->orbitAngle),
	};
	this->moonName = moonName;
	this->scanned = false;
	scan = 1;
}

/**
 * Draw moon in realistic view
 */
void Moon::drawRealistic(bool includeWireFrame){
	glPushMatrix();
		glTranslatef(this->position.x, this->position.y, this->position.z);
		glRotatef(this->rotation, 0.0, 1.0f, 0.0f);
		glScalef(this->moonRadius, this->moonRadius, this->moonRadius);
		glBindTexture(GL_TEXTURE_2D, this->texture);
		setMaterial(1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 100.0f, 0.0f, 0.0f, 0.0f);
		drawSphere();
	glPopMatrix();
	if(includeWireFrame){
		glDisable(GL_LIGHTING);
		glPushMatrix();
		glColor3f(1.0f, 1.0f, 1.0f);
		float rot = 360/7;
		for(int i = 0; i < 7; i++){
			glPushMatrix();
				glTranslatef(this->position.x, this->position.y, this->position.z);
				glRotatef(rot*i, 0.0, 1.0f, 0.0f);
				glScalef(this->moonRadius, this->moonRadius, this->moonRadius);
				drawCircle();
			glPopMatrix();
		}
		for(int i = -2; i < 3; i++){
			float trans = ((float)i)/3.0 * this->moonRadius;
			float radScale = pow(this->moonRadius,2) - pow((((float)abs(i)/3)*this->moonRadius),2);
			if(radScale < 0){
				radScale = 0.2;
			}else{
				radScale = sqrt(radScale);
			}
			glPushMatrix();
				glTranslatef(this->position.x, this->position.y + trans, this->position.z);
				glRotatef(90, 1.0, 0.0f, 0.0f);
				glScalef(radScale, radScale, this->moonRadius);
				drawCircle();
			glPopMatrix();
		}
	}
	glPopMatrix();
	glEnable(GL_LIGHTING);
}

/**
 * Draw moon in orbit view
 */
void Moon::drawOrbit(){
	glPushMatrix();
		glTranslatef(this->position.x, this->position.z, 0.0f);
		glScalef(this->moonRadius, this->moonRadius, this->moonRadius);
		drawCircle();
		drawString(moonName);
	glPopMatrix();
}

/**
 * Draw moons orbit path for orbit view
 */
void Moon::drawOrbitPath(){
	glPushMatrix();
		glScalef(this->orbitRadius, this->orbitRadius, this->orbitRadius);
		drawCircle();
	glPopMatrix();
}

/**
 * Increase scan amount
 */
float Moon::increaseScan(float inc){
	if(!scanned && scan-inc < -1){
		scan = -1;
		scanned = true;
	}
	if(!scanned){
		scan -= inc;
	}
	return scan;
}

/**
 * Draw scan progression for scan view
 */
void Moon::drawScan(){

	glPushMatrix();
		glColor3f(1.0f, 1.0f, 1.0f);
		glBindTexture(GL_TEXTURE_2D, this->texture);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0,0.0); glVertex3f(-1, -1, 0.0);
			glTexCoord2f(1.0,0.0); glVertex3f(1, -1, 0.0);
			glTexCoord2f(1.0,1.0); glVertex3f(1, 1, 0.0);
			glTexCoord2f(0.0,1.0); glVertex3f(-1, 1, 0.0);
		glEnd();
	glPopMatrix();

	glPushMatrix();
		glColor3f(0.0f, 1.0f, 0.0f);
		for(int i = -10; i < 10; i++){
			float blah = i/5.0;
			glBegin(GL_LINES);
				glVertex3f(-1,blah,0.0);
				glVertex3f(1,blah,0.0);
				glVertex3f(blah,-1,0.0);
				glVertex3f(blah,1,0.0);
			glEnd();
		}
	glPopMatrix();

	glPushMatrix();
		glColor3f(1.0f, 0.0f, 0.0f);
		glBegin(GL_QUADS);
			glVertex3f(-1, -1, 0.0);
			glVertex3f(scan, -1, 0.0);
			glVertex3f(scan, 1, 0.0);
			glVertex3f(-1, 1, 0.0);
		glEnd();
	glPopMatrix();
}

/**
 * Update the moons position
 */
void Moon::updatePosition(float deltaTime){
	this->orbitAngle += 0.2f * deltaTime;
	this->rotation += rotationInc;
	this->position = {
			this->orbitRadius * cosf(this->orbitAngle),
			0.0f,
			this->orbitRadius * sinf(this->orbitAngle),
	};
}

Moon::~Moon() {
	// TODO Auto-generated destructor stub
}

