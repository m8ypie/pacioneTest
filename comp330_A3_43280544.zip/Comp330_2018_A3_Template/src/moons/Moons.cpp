/*
 * Moons.cpp
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */
#include <stdio.h>
#include "Moons.h"
#include <string>
#include <map>
#include "Moon.h"
#include <vector>
#include "../utilities.h"

const float distanceScale = 1.5;

MoonConfiguration iapetus = {
	"Iapetus",
	"textures/iapetus.jpg",
	10.5f,
	10.0f,
	0.2f
};

MoonConfiguration titan = {
	"Titan",
	"textures/titan.jpg",
	8.5f,
	9.0f,
	0.5f
};


MoonConfiguration rhea = {
	"Rhea",
	"textures/rhea.jpg",
	5.5f,
	8.0f,
	0.2f
};

MoonConfiguration dione = {
	"Dione",
	"textures/dione.jpg",
	3.5f,
	7.0f,
	0.2f
};

MoonConfiguration enceladus = {
	"Enceladus",
	"textures/enceladus.jpg",
	5.5f,
	6.0f,
	0.5f
};

MoonConfiguration mimas = {
	"Mimas",
	"textures/mimas.jpg",
	0.0f,
	4.0f,
	0.2f
};

MoonConfiguration tethys = {
	"Tethys",
	"textures/tethys.jpg",
	2.0f,
	5.0f,
	0.2f
};

Moons::Moons(){
	MoonConfiguration conf[7] = {iapetus, titan, rhea, dione, enceladus, mimas, tethys};
	std::vector<MoonConfiguration> moonsConfig;
	moonsConfig.insert(moonsConfig.end(), conf, conf+7);
	for(int i = 0; i < moonsConfig.size(); i++){
		std::string moonName = moonsConfig[i].moonName;
		std::string texture = moonsConfig[i].texture;
		float orbitAngle = moonsConfig[i].orbitAngle;
		float orbitRadius = moonsConfig[i].orbitRadius*distanceScale;
		float moonRadius = moonsConfig[i].moonRadius;
		moons[moonName] = new Moon(moonName, texture, orbitAngle, orbitRadius, moonRadius);
	}
	scanInc = 0.001;
}

/**
 * Draw all moons in realistic viewport
 */
void Moons::drawRealistic(std::string moonName, bool includeWireFrame){
	std::map <std::string, Moon*>::iterator it;
	for(it = moons.begin(); it != moons.end(); it++ ){
		if(includeWireFrame && it->first.compare(moonName) == 0){
			it->second->drawRealistic(true);
		}else{
			it->second->drawRealistic(false);
		}
	}
}

/**
 * Draw all moons in orbit viewport
 */
void Moons::drawOrbit(){
	std::map <std::string, Moon*>::iterator it;
	for(it = moons.begin(); it != moons.end(); it++ ){
		it->second->drawOrbit();
	}
}
/**
 * Draw the selected moons orbit path
 */
void Moons::drawOrbitPath(std::string moon){
	moons[moon]->drawOrbitPath();
}

/**
 * Get selected moons position
 */
Vector3 Moons::getMoonPos(std::string moonName){
	return moons[moonName]->position;
}
/**
 * Update all moons positions
 */
void Moons::updatePosition(float deltaTime){
	std::map <std::string, Moon*>::iterator it;
	for(it = moons.begin(); it != moons.end(); it++ ){
		it->second->updatePosition(deltaTime);
	}
}
/**
 * Draw selected moons scan viewport
 */
void Moons::drawScan(std::string moon){
	moons[moon]->drawScan();
}

/**
 * Increase selected moons scan progression
 */
float Moons::incMoonScan(std::string moon){
	return moons[moon]->increaseScan(scanInc);
}

Moons::~Moons() {
	// TODO Auto-generated destructor stub
}

