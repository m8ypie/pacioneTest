/*
 * Plant.h
 *
 *  Created on: 19May,2018
 *      Author: guy_w
 */

#ifndef MOON_H_
#define MOON_H_
#include "../utilities.h"
#include <string>

class Moon {
private:
	std::string moonName;
	unsigned int texture;
	float orbitAngle;
	float orbitRadius;
	float moonRadius;
	float rotation;
	float scan;
	bool scanned;
public:
	Vector3 position;
	Moon(
		std::string moonName,
		std::string texture,
		float orbitAngle,
		float orbitRadius,
		float moonRadius
	);
	void drawRealistic(bool includeWireFrame);
	void drawOrbit();
	void drawScan();
	void drawOrbitPath();
	float increaseScan(float inc);
	void updatePosition(float deltaTime);
	virtual ~Moon();
};

#endif /* MOON_H_ */
