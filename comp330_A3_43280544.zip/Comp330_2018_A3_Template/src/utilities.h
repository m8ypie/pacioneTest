/*
 * File: utilities.h
 * Author: Peter Reeves
 * Date 27 April 2018
 */
#ifndef UTILITIES_H
#define UTILITIES_H
#include <string>
struct Rect {
	int bottomLeftX;
	int bottomLeftY;
	int topRightX;
	int topRightY;
};

struct Vector2 {
	float x;
	float y;
};

struct Vector3 {
	float x;
	float y;
	float z;
};

// Returns a random float between 0 and 1
float randFloat ();

int loadGLTexture (const char *fileName);

void drawString (std::string s);

// All parameters are 0 to 1 except for shininess which is 0 to 128
void setMaterial (
		float diffuseR, float diffuseG, float diffuseB,
		float specularR, float specularG, float specularB,
		float shininess,
		float emissionR, float emissionG, float emissionB
	);

#endif /* UTILITIES_H */
