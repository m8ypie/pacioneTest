/*
 * SkyBox.cpp
 *
 *  Created on: 20May,2018
 *      Author: guy_w
 */

#include "SkyBox.h"
#include "shapes.h"
#include <GL/glut.h>
#include <GL/glu.h>
#include <vector>
#include <stdio.h>
#include <math.h>
SkyBox::SkyBox(){
	float bound = 25;
	for(int i = 0; i < 100; i++){
		int LO = -40;
		int HI = 40;
		float y = LO + static_cast <float> (rand()) /( static_cast <float> (RAND_MAX/(HI-LO)));
		float x = LO + static_cast <float> (rand()) /( static_cast <float> (RAND_MAX/(HI-LO)));
		float z = LO + static_cast <float> (rand()) /( static_cast <float> (RAND_MAX/(HI-LO)));
		if(((z < bound && z > -bound) && (x < bound && x > -bound))){
			i--;
		}else{
			Vector3 blah = {
					x,
					y,
					z
			};
			this->stars.push_back(blah);
		}
	}
}

/**
 * Draw stars
 */
void SkyBox::drawBox(){

	glPushMatrix();
		glColor3f(1.0f, 1.0f, 1.0f);
		glPointSize ( 1.0 );
		setMaterial(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 100.0f, 1.0f, 1.0f, 1.0f);
		std::vector <Vector3>::iterator it;
		glBegin(GL_POINTS);
		for(it = stars.begin(); it != stars.end(); it++ ){
			glVertex3f(it->x, it->y, it->z);
		}
		glEnd();
	glPopMatrix();
}
